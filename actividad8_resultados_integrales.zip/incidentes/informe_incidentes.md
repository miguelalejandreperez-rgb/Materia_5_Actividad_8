# Continuidad operativa del modelo de riesgo crediticio

## Propuesta de valor

Un modelo de riesgo crediticio genera valor cuando ofrece resultados confiables y oportunos. La monitorización permite anticipar desviaciones, actuar antes de que se amplifiquen y conservar evidencia de las decisiones tomadas.

## Situación de referencia

El modelo validado alcanzó un recall de **81.54%** en **6,000 registros históricos de prueba**. La política de servicio establece al menos **99%** de disponibilidad y **95%** de respuestas en **40 ms o menos** en el entorno medido.

## Incidente 1. Integridad de los datos

Se alteró deliberadamente la codificación del historial de pagos en una copia de los registros. El recall pasó de **81.54%** a **70.31%** y el PSI de PAY_0 alcanzó **13.46**. El procedimiento **RB-03** restauró los datos verificados, recuperando el recall a **81.54%**.

**Valor para el negocio:** reduce el riesgo de decisiones basadas en datos incorrectos y facilita la identificación temprana de desviaciones.

## Incidente 2. Tiempo de respuesta

Una demora controlada elevó la latencia p95 de **39.02 ms** a **86.87 ms**. La política de alertamiento activó el procedimiento **RB-02** en la solicitud **300**, retirando automáticamente la demora. La latencia p95 posterior fue de **5.26 ms** y la recuperación del estado de alerta quedó registrada en la solicitud **650**.

**Valor para el negocio:** contribuye a mantener una experiencia ágil y reduce el tiempo necesario para identificar y corregir incidentes.

## Recomendación

Adoptar un proceso de monitorización preventiva con responsabilidades claras, reglas de alerta revisables y procedimientos de recuperación documentados. La validación de cambios que puedan afectar decisiones crediticias debe permanecer bajo supervisión humana.

## Alcance de los resultados

Los resultados se obtuvieron mediante simulaciones controladas con datos históricos y ejecución local. No representan un despliegue productivo ni permiten estimar por sí solos ahorros monetarios o impacto financiero real.
