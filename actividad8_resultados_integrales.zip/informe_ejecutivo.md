# Propuesta de monitorización y continuidad del riesgo crediticio

## Problema de negocio
El uso de modelos predictivos en decisiones de riesgo requiere garantizar calidad de la información, transparencia y respuestas oportunas. Un deterioro no detectado puede afectar las decisiones y aumentar el esfuerzo operativo.

## Resultados del modelo
En 6,000 registros históricos, el modelo registró un ROC-AUC de **0.777** y un recall de **81.54%** para detectar incumplimientos, con una tasa de alertas crediticias de **54.43%**.

## Confiabilidad y objetivos
La política de prueba fija una disponibilidad objetivo de **99%** y al menos **95%** de respuestas dentro de **40 ms**. En 500 solicitudes locales de referencia, la disponibilidad registrada fue **100.00%** y el cumplimiento de latencia **99.60%**. El motor utiliza reglas de prioridad, ventanas y deduplicación.

## Incidentes controlados
**Calidad de datos:** el recall pasó de 81.54% a 70.31% tras una alteración deliberada y recuperó 81.54% después de restaurar datos verificados.

**Latencia:** la latencia p95 pasó de 39.02 ms a 86.87 ms y, después de la acción correctiva, bajó a 5.26 ms. La alerta se generó y se registró la recuperación.

## Beneficios propuestos
- Anticipar incidentes que pueden afectar la confianza en las evaluaciones crediticias.
- Facilitar la detección de variaciones en la calidad de los datos y preservar un modelo validado.
- Reducir el tiempo de identificación y respuesta ante lentitud del sistema.
- Mantener trazabilidad de métricas, alertas, acciones y responsables.

## Recomendación
Proponer una adopción gradual de monitorización preventiva y revisión periódica de los indicadores, manteniendo supervisión humana en cambios que puedan afectar decisiones crediticias.

## Alcance
Los resultados provienen de datos históricos y pruebas controladas en Google Colab. No demuestran comportamiento en un servicio productivo ni permiten cuantificar ahorros financieros reales.
